For more information about running Artifactory inside IBM WebSphere please visit:

http://wiki.jfrog.org/confluence/display/RTF/Deploying+on+IBM+Websphere